

// var coupon = document.getElementById("couponCode").innerHTML;
// var a = "FIFTYFIFTY";
//
// document.getElementById("btnCoupon").addEventListener("click", function(){
//   if (coupon === a){
//     alert("HELLO");
//   }
//   else{
//     alert("BYE");
//   }
//
// });

var cartCount = 0;
var cart = document.getElementById("goToCart").addEventListener("click", function(){

  if(cartCount == 0){
    alert("No");
  }
  else{
    alert("HEllo");
  }


});
